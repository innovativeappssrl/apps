# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '7aee573b7efcec05b0f78a8ab18da441e0c9cbec9aad347a12753a50b03a81ac89a8427197c57754e95f3791173683e5cc53b46111f25b44865d705ca31a9ab4'
