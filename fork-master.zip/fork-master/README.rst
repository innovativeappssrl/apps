Acerca de
---------------
Guía: "Fork de repositorios en Github" de: http://aprendegit.com

Resumen
---------------
Resumiendo un poco el proceso:
http://aprendegit.com/fork-de-repositorios-para-que-sirve/

1) Ir al repositorio a colaborar.
2) Realizar un fork de ese repositorio.
3) Clonar el fork.
4) Hacer los cambios al fork.
5) Subir los cambios del fork con push.

Resumen realizado por: Wuilmer Bolivar 
Twitter: @WuilmerBolivar

Pruebas
---------------
Prueba de modificación de un fichero cualquiera por @jorgejiro

Modificación de @aalbagarcia después del pull request para que @jorgejiro 
practique a sincronizar sus fork... si quiere ;-)
Modificacion hecha por @SakyaStelios, aprendiendo a usar git
Última prueba de pull request (BAstante fácil el tutorial)

Cambio esto :)
y esto :P -
